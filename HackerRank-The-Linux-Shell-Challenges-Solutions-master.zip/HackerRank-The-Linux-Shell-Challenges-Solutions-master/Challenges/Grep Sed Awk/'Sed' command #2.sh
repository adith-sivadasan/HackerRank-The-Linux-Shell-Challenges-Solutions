sed -e 's/thy /your /gI'
