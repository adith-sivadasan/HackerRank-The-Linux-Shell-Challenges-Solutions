# Only display those lines that do NOT contain the word 'that'. The relative ordering of the lines should be the same as it was in the input file.

grep -iv "that"
