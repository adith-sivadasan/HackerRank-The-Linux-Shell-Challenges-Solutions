#We retain only those lines which have at least one of the following words: 
# the 
# that 
# then 
# those
grep -iwe "the\|that\|then\|those"

