# Display a range of characters starting at the 2nd position of a string and ending at the 7th position (both positions included)
cut -c 2-7