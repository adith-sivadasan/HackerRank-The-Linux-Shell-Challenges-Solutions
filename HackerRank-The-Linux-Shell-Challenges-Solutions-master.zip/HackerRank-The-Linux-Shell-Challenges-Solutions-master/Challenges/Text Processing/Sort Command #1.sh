#Output the text file with the lines reordered in lexicographical order. 
sort