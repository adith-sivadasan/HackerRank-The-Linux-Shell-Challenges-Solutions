#The output should contain N lines. For each input sentence, identify and display its first three words. Assume that the space (' ') is the only delimiter between words. 
cut -d " " -f 1-3

