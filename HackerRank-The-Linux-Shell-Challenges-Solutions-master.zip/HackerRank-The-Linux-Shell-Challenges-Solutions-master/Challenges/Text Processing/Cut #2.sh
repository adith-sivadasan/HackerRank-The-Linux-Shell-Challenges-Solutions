#Display the 2nd and 7th character from each line of text. 
cut -c 2,7