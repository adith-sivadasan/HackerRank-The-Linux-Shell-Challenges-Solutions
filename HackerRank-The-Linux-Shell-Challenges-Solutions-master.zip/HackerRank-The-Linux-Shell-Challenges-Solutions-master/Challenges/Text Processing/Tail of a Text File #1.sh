#Output the last 20 lines of the text file. 
tail -20