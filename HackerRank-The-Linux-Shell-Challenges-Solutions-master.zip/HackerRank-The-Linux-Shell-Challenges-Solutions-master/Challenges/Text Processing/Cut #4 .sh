#Display the first four characters from each line of text. 
cut -c -4

