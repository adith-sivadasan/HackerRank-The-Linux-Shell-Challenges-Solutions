#Given a text file, remove the consecutive repetitions of any line.
uniq