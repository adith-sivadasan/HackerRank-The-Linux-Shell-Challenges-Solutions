#For each line in the input, print the fields from second fields to last field. 
cut -f 2-

