# Replace the newlines in the input file with semicolons
paste -d";" -s