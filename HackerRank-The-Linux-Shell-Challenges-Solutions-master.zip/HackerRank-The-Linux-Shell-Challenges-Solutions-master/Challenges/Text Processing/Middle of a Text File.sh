#Display the lines (from line number 12 to 22, both inclusive) for the input file. 
head -22 | tail -11