#Given a tab delimited file with several columns (tsv format) print the first three fields.
cut -f 1-3