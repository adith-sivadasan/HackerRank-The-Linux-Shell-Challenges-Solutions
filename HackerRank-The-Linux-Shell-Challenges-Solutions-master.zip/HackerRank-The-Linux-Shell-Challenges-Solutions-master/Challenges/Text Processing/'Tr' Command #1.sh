#Output the text with all parentheses () replaced with box brackets []. 
tr "()" "[]"
