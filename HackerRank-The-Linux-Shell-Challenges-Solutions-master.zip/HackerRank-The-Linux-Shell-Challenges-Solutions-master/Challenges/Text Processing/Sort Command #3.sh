#Output the text file with the lines reordered in numerically ascending order.
sort -n