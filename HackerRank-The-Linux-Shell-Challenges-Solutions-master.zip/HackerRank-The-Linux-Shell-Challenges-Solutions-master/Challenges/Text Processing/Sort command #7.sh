#The data has been sorted in descending order of the average monthly temperature in January (i.e, the second column). 
sort -k2 -n -r -t '|'

