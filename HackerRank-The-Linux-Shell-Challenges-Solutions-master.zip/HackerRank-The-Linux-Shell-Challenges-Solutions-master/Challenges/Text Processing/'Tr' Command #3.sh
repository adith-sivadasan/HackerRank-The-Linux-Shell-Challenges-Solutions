#Replace all sequences of multiple spaces with just one space.
tr -s ' '
