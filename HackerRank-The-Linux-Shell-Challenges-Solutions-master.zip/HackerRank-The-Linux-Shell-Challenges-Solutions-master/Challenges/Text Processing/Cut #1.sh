# print the 3rd character from each line as a new line of output.
cut -c 3