#Output the text file with the lines reordered in reverse lexicographical order. 
sort -r