#Print the characters from thirteenth position to the end.
cut -c 13-