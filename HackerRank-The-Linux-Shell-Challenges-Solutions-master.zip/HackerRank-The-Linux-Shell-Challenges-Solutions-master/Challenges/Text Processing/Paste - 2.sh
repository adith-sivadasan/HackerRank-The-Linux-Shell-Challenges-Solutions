#Restructure the file so that three consecutive rows are folded into one line and are separated by semicolons. 
paste -d ";" - - -