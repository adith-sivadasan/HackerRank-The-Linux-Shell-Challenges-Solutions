#Output the first 20 lines of the given text file. 
head -20

