# For each input sentence, identify and display its fourth word. Assume that the space (' ') is the only delimiter between words. 
cut -d " " -f 4