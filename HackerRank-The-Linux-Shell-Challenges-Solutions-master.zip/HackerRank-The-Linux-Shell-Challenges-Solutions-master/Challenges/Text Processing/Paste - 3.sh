# The delimiter between consecutive rows of data has been transformed from the newline to a tab. 
# Previous solution: paste -s -d"\\t"
# The delimiter option is not necessary as tab is the delimiter of paste by default
paste -s 