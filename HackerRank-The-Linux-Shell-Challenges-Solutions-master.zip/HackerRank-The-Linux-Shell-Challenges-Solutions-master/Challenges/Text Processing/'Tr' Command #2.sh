#In a given fragment of text, delete all the lowercase characters a - z.
tr -d "a-z"