#Display the last 20 characters of an input file.
tail -c 20