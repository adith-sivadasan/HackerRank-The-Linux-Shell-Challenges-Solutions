#The text file, with lines re-ordered in descending order (numerically).
sort -n -r

