# Restructure the file in such a way, that every group of three consecutive rows are folded into one, and separated by tab. 
paste - - -