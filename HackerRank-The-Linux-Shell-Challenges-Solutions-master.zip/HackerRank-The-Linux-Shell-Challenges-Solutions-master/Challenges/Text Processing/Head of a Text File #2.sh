#Output the first 20 characters of the text file
head -c 20

