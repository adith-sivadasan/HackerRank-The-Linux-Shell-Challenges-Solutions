#The data has been sorted in ascending order of the average monthly temperature in January (i.e, the second column) in a tsv file
sort -n -k2 -t$'\t'

